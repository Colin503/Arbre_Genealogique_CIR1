//
// Created by colin on 17/06/2024.
//

#ifndef S2_PROJETFINAL_HTMLEXPORT_H
#define S2_PROJETFINAL_HTMLEXPORT_H
#include "advanced.h"

int titreHTMLPerson(char* buffer, Person* p);
int fichePath(char* buffer, Person* p);
void exportPersonHTML(const Population t,Person* p, char* path);



#endif //S2_PROJETFINAL_HTMLEXPORT_H
