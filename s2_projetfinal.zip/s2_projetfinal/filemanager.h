//
// Created by colin on 14/06/2024.
//

#ifndef S2_PROJETFINAL_FILEMANAGER_H
#define S2_PROJETFINAL_FILEMANAGER_H
#include "population.h"

Population read_csv(const char* filename);


#endif //S2_PROJETFINAL_FILEMANAGER_H

