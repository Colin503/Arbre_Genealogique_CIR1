#include "menu.h"

int main() {
    Population pop;
    char path[30];
    pop = read_csv("../resources/10000.csv");
    linkPopulation(pop);
    Person** tab_fratrie= fratrie(pop,pop.tab_personne[4576]);
    affichage_tableau(tab_fratrie);
    printf("%s %d\n",path,fichePath(path, pop.tab_personne[4567]));
    exportPersonHTML(pop,pop.tab_personne[4576],path);

    free(tab_fratrie);
    return 0;
}