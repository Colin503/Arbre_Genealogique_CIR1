//
// Created by colin on 17/06/2024.
//

#ifndef S2_PROJETFINAL_MENU_H
#define S2_PROJETFINAL_MENU_H

#include "htmlexport.h"

void menu(Population t,Person** tab);
void affichage_tableau(Person** tab);

#endif //S2_PROJETFINAL_MENU_H
